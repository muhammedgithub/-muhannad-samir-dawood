package com.pharmacy.nam;

public class About {

	public static String buildString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("-------------------------------------------------------");
		sb.append("\n");
		sb.append("A b o u t :");
		sb.append("\n");
		sb.append("This Project requested from Mohammed Essa,");
		sb.append("\n");
		sb.append("that when getting the JAVA Training in the IHEC office,");
		sb.append("\n");
		sb.append("and created it by a group:");
		sb.append("\n");
		sb.append("1. Nazar Ahmed Awad.\n");
		sb.append("2. Ahmed Essam Badr.\n");
		sb.append("3. Mohand Samir Dawood.\n");
		sb.append("with best regards");
		return sb.toString();
	}
}
